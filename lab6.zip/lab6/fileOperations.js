const fs = require('fs');

function writeFilePromise(fileName, content) {
    return new Promise((resolve, reject) => {
        fs.writeFile(fileName, content, (err) => {
            if (err) {
                reject("Error writing file: " + err);
            } else {
                resolve("Success!");
            }
        });
    });
}

function readFilePromise(fileName) {
    return new Promise((resolve, reject) => {
        fs.readFile(fileName, 'utf-8', (err, data) => {
            if (err) {
                reject("Error reading file: " + err);
            } else {
                resolve(data);
            }
        });
    });
}

writeFilePromise("userData.txt", "Hello, this is a test message!")
    .then((message) => {
        console.log(message); // Outputs: Success!
        return readFilePromise("userData.txt"); // Read file after successful write
    })
    .then((data) => {
        console.log("Data:", data); // Outputs: Data: Hello, this is a test message!
    })
    .catch((error) => {
        console.error(error); // Handles any errors in the flow
    });